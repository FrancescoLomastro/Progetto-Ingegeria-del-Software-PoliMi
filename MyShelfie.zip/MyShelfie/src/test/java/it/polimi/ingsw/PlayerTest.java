package it.polimi.ingsw;

/*We have tried to test this class, but it is unnecessary and too complex.
 * In this class the main method to test is "countFinalPoint()", but it is simply the sum of adjacent and match points(and we already
 * tested them,  we don't mix points' count and match's count).
 * We have tried to create some tests that verify specific score but was too complex. The problem is that instantiation of player/library
 * generates automatically a casual personal goal card. So the test should "understand" which personal goal card is selected and
 * fill null part to reach specific points with adjacent. That last generation of objectCard can't be random because library
 * must have specific match also
 * */


public class PlayerTest {

}
