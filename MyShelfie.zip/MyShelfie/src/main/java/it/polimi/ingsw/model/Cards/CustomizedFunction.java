package it.polimi.ingsw.model.Cards;

public interface CustomizedFunction<T> {
    T apply();
}
