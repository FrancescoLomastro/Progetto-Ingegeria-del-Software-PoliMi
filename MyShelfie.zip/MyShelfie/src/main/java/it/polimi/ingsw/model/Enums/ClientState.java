package it.polimi.ingsw.model.Enums;

public enum ClientState {
    CHAT,REQUEST;
}
