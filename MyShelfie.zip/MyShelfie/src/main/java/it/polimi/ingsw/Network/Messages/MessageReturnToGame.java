package it.polimi.ingsw.Network.Messages;

public class MessageReturnToGame extends MessageGame{
    public MessageReturnToGame(MessageType msg){
        super(msg);
    }
}
