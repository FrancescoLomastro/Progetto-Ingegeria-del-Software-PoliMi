package it.polimi.ingsw.model.Utility;

public enum ConnectionMode {
    RMI,SOCKET;
}
