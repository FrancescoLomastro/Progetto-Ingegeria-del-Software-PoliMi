package it.polimi.ingsw.Network.Messages;

public class BasicMessage extends Message{
    public BasicMessage(String senderUsername, MessageType type) {
        super(senderUsername, type);
    }

}
